package com.example.jhpark.mytictactoc;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {
    int i;

    Button button[] = new Button[9];
    int btnID[] = {R.id.button1, R.id.button2, R.id.button3, R.id.button4, R.id.button5,
            R.id.button6, R.id.button7, R.id.button8, R.id.button9};

    int btnCheck[] = new int[9];
    int player = 1;
    int id, find;
    boolean bingo = true;
    int coloring[] = new int[3];
    String color;

    Button btnRes;
    ImageView ivPlayer;
    TextView tvWinner;
    TextView tvPlayer;
    Handler m_handler;
    Runnable m_taskr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for ( i = 0; i < 9; i++) {
            button[i] = (Button) findViewById(btnID[i]);
            btnCheck[i] = 0;
        }

        ivPlayer = (ImageView) findViewById(R.id.ivPlayer);
        tvPlayer = (TextView) findViewById(R.id.tvPlayer);
        tvWinner = (TextView) findViewById(R.id.tvWinner);

        btnRes = (Button) findViewById(R.id.btnRes);
        btnRes.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                for ( i = 0; i < 9; i++) {
                    button[i].setText(null);
                    btnCheck[i] = 0;
                }
                bingo = true;
                Coloring("#FFD0D0D0");
            }
        });

        for ( i = 0; i < 9; i++) {
            button[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    id = v.getId();

                    m_handler.postDelayed(m_taskr, 1000);
                }
            });
        }

        m_handler = new Handler();
        m_taskr = new Runnable() {
            @Override
            public void run() {
                if (bingo) {
                    FindButton();
                    MakeT(button[find]);
                }
                else {
                    Toast.makeText(getApplicationContext(),
                            "RESET 버튼을 눌러주세요.", Toast.LENGTH_LONG).show();
                }
            }
        };
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (m_handler != null) {
            m_handler.removeCallbacks(m_taskr);
        }
    }

    public void FindButton () {
        for ( i = 0; i<9;i++) {
            if (id == button[i].getId()) {
                find = i;
            }
        }
    }

    public void MakeT(Button button) {
        if (btnCheck[find] == 0) {
            if (player == 1) {
                button.setText("O");
                btnCheck[find] = 1;
                if (Bingo()) {
                    Coloring("#FFFFE3FE");
                    Toast.makeText(getApplicationContext(),
                            "Player1 승리!", Toast.LENGTH_LONG).show();
                    tvWinner.setText("Last Winner : Player1");
                    bingo = false;
                }
                else if (Tie()) {
                    Toast.makeText(getApplicationContext(),
                            "무승부!", Toast.LENGTH_LONG).show();
                    bingo = false;
                }
                player = 2;
                tvPlayer.setText("Player" + player);
                ivPlayer.setBackgroundColor(Color.parseColor("#FFFE986C"));
            }
            else {
                button.setText("X");
                btnCheck[find] = 2;
                if (Bingo()) {
                    Coloring("#FFFFE3FE");
                    Toast.makeText(getApplicationContext(),
                            "Player2 승리!", Toast.LENGTH_LONG).show();
                    tvWinner.setText("Last Winner : Player2");
                    bingo = false;
                }
                else if (Tie()) {
                    Toast.makeText(getApplicationContext(),
                            "무승부!", Toast.LENGTH_LONG).show();
                    bingo = false;
                }
                player = 1;
                tvPlayer.setText("Player" + player);
                ivPlayer.setBackgroundColor(Color.parseColor("#fede6c"));
            }
        }
        else {
            Toast.makeText(getApplicationContext(),
                    "이미 누르셨습니다.", Toast.LENGTH_LONG).show();
        }
    }

    public boolean Bingo() {
        if (btnCheck[0] != 0) {
            if (btnCheck[0] == btnCheck[1] && btnCheck[0] == btnCheck[2]) {
                int color[] = {0, 1, 2};
                coloring = color;
                return true;
            }
            else if (btnCheck[0] == btnCheck[3] && btnCheck[0] == btnCheck[6]) {
                int color[] = {0, 3, 6};
                coloring = color;
                return true;
            }
        }
        if (btnCheck[4] != 0 ) {
            if (btnCheck[4] == btnCheck[3] && btnCheck[4] == btnCheck[5]) {
                int color[] = {3, 4, 5};
                coloring = color;
                return true;
            }
            else if (btnCheck[4] == btnCheck[1] && btnCheck[4] == btnCheck[7]) {
                int color[] = {1, 4, 7};
                coloring = color;
                return true;
            }
            else if (btnCheck[4] == btnCheck[0] && btnCheck[4] == btnCheck[8]) {
                int color[] = {0, 4, 8};
                coloring = color;
                return true;
            }
            else if (btnCheck[4] == btnCheck[2] && btnCheck[4] == btnCheck[6]) {
                int color[] = {2, 4, 6};
                coloring = color;
                return true;
            }
        }
        if (btnCheck[8] != 0) {
            if (btnCheck[8] == btnCheck[6] && btnCheck[8] == btnCheck[7]) {
                int color[] = {6, 8, 7};
                coloring = color;
                return true;
            }
            else if (btnCheck[8] == btnCheck[2] && btnCheck[8] == btnCheck[5]) {
                int color[] = {2, 5, 8};
                coloring = color;
                return true;
            }
        }
        return false;
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void Coloring(String color) {
        button[coloring[0]].setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(color)));
        button[coloring[1]].setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(color)));
        button[coloring[2]].setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(color)));
    }

    public boolean Tie() {
        for ( i = 0; i <9; i++) {
            if (btnCheck[i] == 0) {
                return false;
            }
        }
        return true;
    }
}